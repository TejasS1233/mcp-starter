# mcp-starter

Beginner-friendly MCP setup manager.

`mcp-starter` helps you configure MCP servers for Claude Code, OpenCode, and Cursor without config-file confusion.

It is intentionally focused on setup UX (menu + guided CLI), not on running a full MCP gateway server.

## Positioning

- `mcp-starter` = setup/orchestration utility for beginners
- Not a replacement for runtime MCP gateway servers
- Best for: quick local setup, project-vs-global profiles, preset installs, auth env wiring

## Features

- Guided menu mode: `menu`
- Quick setup modes:
  - minimal essentials
  - all essentials
- Scope selection:
  - project-local (`.claude/.opencode/.cursor`)
  - global (`~/.claude`, `~/.config/opencode`, `~/.cursor`)
- Preset catalog with auth hints
- Auth helpers (`auth set/login/show`)
- Import existing MCP entries from target configs
- Backup existing target configs (`.bak`) on apply

## 30-second start

```bash
cd mcp-hub
npm install
node src/index.js menu
```

Then choose:
1. Quick setup (all essentials)
2. project or global scope
3. auth setup (if needed)
4. apply

## Fast non-interactive setup

```bash
node src/index.js setup --yes --scope project --mode all
node src/index.js validate
```

## Presets and auth

View presets:

```bash
node src/index.js presets
```

Add a preset or custom MCP:

```bash
node src/index.js add github --package @modelcontextprotocol/server-github --env "GITHUB_TOKEN=ghp_xxx"
node src/index.js add jira --package @example/jira-mcp --args "--project,ABC"
```

Auth commands:

```bash
node src/index.js auth set github --env "GITHUB_TOKEN=ghp_xxx"
node src/index.js auth login github
node src/index.js auth show github
```

Apply to targets:

```bash
node src/index.js apply
```

## Commands

```bash
node src/index.js help
node src/index.js menu
node src/index.js setup [--yes] [--scope global|project] [--mode minimal|all]
node src/index.js presets
node src/index.js list
node src/index.js validate
node src/index.js apply
node src/index.js import

node src/index.js add <serverId> --package <npmPackage> [--args "a,b"] [--env "K=V,K2=V2"]
node src/index.js remove <serverId>
node src/index.js enable <serverId>
node src/index.js disable <serverId>

node src/index.js auth set <serverId> --env "K=V,K2=V2"
node src/index.js auth login <serverId>
node src/index.js auth show <serverId>

node src/index.js guard check --server <serverId> --action <name>
node src/index.js guard run --server <serverId> --action <name>
node src/index.js supervise start --restarts 3
```

## Testing

```bash
npm run test:smoke
```
